#include "Controller.h"
#include <memory>

using namespace std;

Controller::Controller()
{
	this->adminList = new MovieRepository();
	this->userList = new TXTRepository();
	this->movieValidator = MovieValidator();
	this->repoValidator = RepositoryValidator();
	this->currentMoviePosition = 0;
}

Controller::Controller(MovieRepository* adminList)
{
	this->adminList = adminList;
	this->userList = new TXTRepository();
	this->movieValidator = MovieValidator();
	this->repoValidator = RepositoryValidator();
	this->currentMoviePosition = 0;
}

void Controller::addMovie(Movie movie)
{
	this->movieValidator.validateMovie(movie);
	this->repoValidator.validateAdd(movie, adminList->getAllMovies());
	adminList->addMovie(movie);
	adminList->writeToFile();

	UndoRedoAdd undoRedoAddOperation = UndoRedoAdd(movie, *adminList);
	unique_ptr<UndoRedoAction> pointer = std::make_unique<UndoRedoAdd>(undoRedoAddOperation);
	this->undoActions.push_back(std::move(pointer));
}

void Controller::updateMovie(Movie movie)
{
	this->movieValidator.validateMovie(movie);
	this->repoValidator.validateUpdate(movie, adminList->getAllMovies());

	Movie oldMovie = adminList->getMovieByTitle(movie.getTitle());

	adminList->updateMovie(movie);
	adminList->writeToFile();

	UndoRedoUpdate undoRedoAddOperation = UndoRedoUpdate(oldMovie, movie, *adminList);
	unique_ptr<UndoRedoAction> pointer = std::make_unique<UndoRedoUpdate>(undoRedoAddOperation);
	this->undoActions.push_back(std::move(pointer));
}

void Controller::deleteMovie(std::string movieTitle)
{
	this->repoValidator.validateDelete(movieTitle, adminList->getAllMovies());
	Movie movieToDelete = adminList->getMovieByTitle(movieTitle);
	adminList->deleteMovie(movieToDelete);
	adminList->writeToFile();

	UndoRedoDelete undoRedoAddOperation = UndoRedoDelete(movieToDelete, *adminList);
	unique_ptr<UndoRedoAction> pointer = std::make_unique<UndoRedoDelete>(undoRedoAddOperation);
	this->undoActions.push_back(std::move(pointer));
}

std::vector<Movie> Controller::getAllMovies() const
{
	return adminList->getAllMovies();
}

void Controller::loadMovieRepo(std::string filePath)
{
	delete this->adminList;
	this->adminList = new TXTRepository();
	this->adminList->readFromFile(filePath);
}

bool Controller::undo()
{
	if (this->undoActions.size() >= 1)
	{
		int index = this->undoActions.size() - 1;

		this->undoActions[index]->executeUndo();

		unique_ptr<UndoRedoAction> pointer = std::move(this->undoActions[index]);
		// try with .back().get() if this fails
		// check if the shit moves correctly

		this->undoActions.pop_back();

		this->redoActions.push_back(std::move(pointer));


		return true;
	}

	else
		return false;
}

bool Controller::redo()
{
	if (this->undoActions.size() >= 1)
	{
		int index = this->redoActions.size() - 1;

		this->redoActions[index]->executeRedo();

		unique_ptr<UndoRedoAction> pointer = std::move(this->redoActions[index]);
		// try with .back().get() if this fails
		// check if the shit moves correctly

		this->redoActions.pop_back();

		this->undoActions.push_back(std::move(pointer));

		return true;
	}

	else
	return false;
}

Movie Controller::nextMovie()
{
	currentMoviePosition++;
	if (currentMoviePosition < adminList->getNumberOfMovies())
		return adminList->getMovieByPosition(currentMoviePosition);

	currentMoviePosition = 0;
	return adminList->getMovieByPosition(currentMoviePosition);

}

void Controller::saveMovie(std::string movieTitle)
{
	Movie movieToWatch = adminList->getMovieByTitle(movieTitle);
	this->repoValidator.validateAdd(movieToWatch, userList->getAllMovies());
	userList->addMovie(movieToWatch);
	userList->writeToFile();
}

std::vector<Movie> Controller::filterMoviesByGenreLikes(std::string genre, int likes)
{
	return adminList->filterMoviesByGenreLikes(genre, likes);
}

std::vector<Movie> Controller::filterMovieByLikes(int likes)
{
	return adminList->filterMoviesByLikes(likes);
}

std::vector<Movie> Controller::getWatchlist() const
{
	return userList->getAllMovies();
}

void Controller::openWatchlist()
{
	this->userList->openFile();
}

void Controller::setUserListType(std::string filePath, std::string fileExtension)
{
	if (strcmp(fileExtension.c_str(), "csv") == 0) 
	{
		delete this->userList;
		this->userList = new CSVRepository();
	}
	else 
	{
		if (strcmp(fileExtension.c_str(), "html") == 0)
		{
			delete this->userList;
			this->userList = new HTMLRepository();
		}
	}
	userList->setPath(filePath);
}