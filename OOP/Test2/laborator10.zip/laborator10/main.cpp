#include "Lab10.h"
#include "domain.h"
#include "validator.h"
#include "repo.h"
#include "controller.h"
#include "guiLab11.h"


int main(int argc, char *argv[])
{
	TaskRepository *baseRepository = new FileRepository();
	TaskRepository *fileRepository = new FileRepository();
	RepositoryValidator *repoValidator = new RepositoryValidator();
	TaskControllerModeA mainController(baseRepository, fileRepository, repoValidator);
	
	QApplication a(argc, argv);
	
	gui newGui{ mainController };
	newGui.show();

	return a.exec();
}
