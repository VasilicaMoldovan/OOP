#include "guiLab11.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>


gui::gui(TaskControllerModeA controllerRefurbishments) :controllerRefurbishments{ controllerRefurbishments}
{
	this->construct();
	this->getData();
}

gui::~gui() {}

void gui::construct()
{
	QHBoxLayout *newLayout = new QHBoxLayout{ this };

	QVBoxLayout *layoutModeA = new QVBoxLayout{};
	QVBoxLayout *connectingLayout = new QVBoxLayout{};
	QVBoxLayout *layoutModeB = new QVBoxLayout{};

	//mode A
	QLabel *modeALabel = new QLabel();
	modeALabel->setText("Mode A Refurbishments");
	QFont modeAFont("Times New Roman", 16, QFont::Bold);
	modeALabel->setFont(modeAFont);
	layoutModeA->addWidget(modeALabel);

	//mode B
	QLabel *modeBLabel = new QLabel();
	modeBLabel->setText("Mode B Refurbishments");
	QFont modeBFont("Times New Roman", 16, QFont::Bold);
	modeBLabel->setFont(modeBFont);
	layoutModeB->addWidget(modeBLabel);

	this->refurbishmentData = new QListWidget{};
	this->modeBData = new QListWidget{};

	layoutModeA->addWidget(this->refurbishmentData);
	layoutModeB->addWidget(this->modeBData);

	QVBoxLayout *left = new QVBoxLayout{};
	QVBoxLayout *right = new QVBoxLayout{};

	layoutModeA->addLayout(left);
	layoutModeB->addLayout(right);

	QHBoxLayout *modeAButtonsLayout = new QHBoxLayout{};
	QHBoxLayout *modeBButtonsLayout = new QHBoxLayout{};

	modeAButtonsLayout->addWidget(new QPushButton{ "Add" });
	modeAButtonsLayout->addWidget(new QPushButton{ "Remove" });
	modeAButtonsLayout->addWidget(new QPushButton{ "Update" });
	modeBButtonsLayout->addWidget(new QPushButton{ "Next" });
	connectingLayout->addWidget(new QPushButton{ ">>" });

	QHBoxLayout *exitButtonLayout = new QHBoxLayout{};
	QPushButton *exitButton = new QPushButton{ "Exit" };
	exitButton->setMaximumWidth(170);
	exitButtonLayout->addWidget(exitButton);

	QFormLayout *modeARefurbishments = new QFormLayout{};
	QFormLayout *modeBRefurbishments = new QFormLayout{};

	this->title = new QLineEdit{};
	modeARefurbishments->addRow("Title", this->title);
	this->type = new QLineEdit{};
	modeARefurbishments->addRow("Type", this->type);
	this->date = new QLineEdit{};
	modeARefurbishments->addRow("Date", this->date);
	this->numberOfRepetitions = new QLineEdit{};
	modeARefurbishments->addRow("Number of repetitions", this->numberOfRepetitions);
	this->mirrorImage = new QLineEdit{};
	modeARefurbishments->addRow("Vision", this->mirrorImage);

	left->addLayout(modeARefurbishments);
	left->addLayout(modeAButtonsLayout);
	left->addLayout(exitButtonLayout);
	right->addLayout(modeBButtonsLayout);

	newLayout->addLayout(layoutModeA);
	newLayout->addLayout(connectingLayout);
	newLayout->addLayout(layoutModeB);

}

void gui::getData()
{
	this->controllerRefurbishments.readRepositoryFromFile("input.txt");
	for (Refurbishment &task : this->controllerRefurbishments.getAllRefurbishments())
	{
		this->refurbishmentData->addItem(QString::fromStdString(task.toString()));

	}
}