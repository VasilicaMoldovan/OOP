#pragma once
#include "C:\Qt\5.12.3\msvc2017_64\include\QtWidgets\qwidget.h"
#include "Controller.h"
#include <qlistwidget.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <iostream>

class gui : public QWidget
{
private:
	TaskControllerModeA controllerRefurbishments;
	QListWidget *refurbishmentData;
	QListWidget *modeBData;
	QLineEdit *title, *type, *date, *numberOfRepetitions, *mirrorImage;
	QPushButton *addButton, *removeButton, *updateButton;
	void construct();
	void getData();
public:
	gui(TaskControllerModeA controllerRefurbishments);
	~gui();
};

