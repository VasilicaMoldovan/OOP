#pragma once
#include "controller.h"

class Tests {
private:
public:
	void TestDomain();
	void TestController();
	void TestControllerLab9();
};